#.First.lib <- function(lib, pkg)
#{
#    library.dynam("colibri_op_R_c", pkg, lib)
#}
