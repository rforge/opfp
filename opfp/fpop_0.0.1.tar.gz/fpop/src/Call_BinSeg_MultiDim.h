
#include "BinSeg_MultiDim.h"

extern "C" {
void Call_BinSeg (double * dataVec_, int * Kmax_, int * n_, int * P_, int * Ruptures_,  double * RupturesCost_);
}
